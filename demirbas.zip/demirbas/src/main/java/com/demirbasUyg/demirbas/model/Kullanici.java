package com.demirbasUyg.demirbas.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Kullanici")
public class Kullanici {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private long id;
	@Column(name ="Ad")
	private String ad;
	@Column(name ="Soyad")
	private String soyad;
	@Column(name = "Email",nullable = true)
	private String email;
	@Column(name = "TelNo",nullable = true)
	private String telNo;
	@Column(name = "GirisTarihi")
	private LocalDate girisTarihi;
	@Column(name = "CıkısTarihi", nullable = true)
	private LocalDate cıkısTarihi;
	@Column(name = "Durum")
	private int durum;
	
	
	
	
	public Kullanici() {
		super();
	}
	public Kullanici(long id, String ad, String soyad, LocalDate girisTarihi, int durum) {
		super();
		this.id = id;
		this.ad = ad;
		this.soyad = soyad;
		this.girisTarihi = girisTarihi;
		this.durum = durum;
	}
	public Kullanici(long id, String ad, String soyad, String email, String telNo, LocalDate girisTarihi,
			LocalDate cıkısTarihi, int durum) {
		super();
		this.id = id;
		this.ad = ad;
		this.soyad = soyad;
		this.email = email;
		this.telNo = telNo;
		this.girisTarihi = girisTarihi;
		this.cıkısTarihi = cıkısTarihi;
		this.durum = durum;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAd() {
		return ad;
	}
	public void setAd(String ad) {
		this.ad = ad;
	}
	public String getSoyad() {
		return soyad;
	}
	public void setSoyad(String soyad) {
		this.soyad = soyad;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelNo() {
		return telNo;
	}
	public void setTelNo(String telNo) {
		this.telNo = telNo;
	}
	public LocalDate getGirisTarihi() {
		return girisTarihi;
	}
	public void setGirisTarihi(LocalDate girisTarihi) {
		this.girisTarihi = girisTarihi;
	}
	public LocalDate getCıkısTarihi() {
		return cıkısTarihi;
	}
	public void setCıkısTarihi(LocalDate cıkısTarihi) {
		this.cıkısTarihi = cıkısTarihi;
	}
	public int getDurum() {
		return durum;
	}
	public void setDurum(int durum) {
		this.durum = durum;
	}
	
	
	@Override
	public String toString() {
		return "Kullanici [id=" + id + ", ad=" + ad + ", soyad=" + soyad + ", email=" + email + ", telNo=" + telNo
				+ ", girisTarihi=" + girisTarihi + ", cıkısTarihi=" + cıkısTarihi + ", durum=" + durum + "]";
	}
}
