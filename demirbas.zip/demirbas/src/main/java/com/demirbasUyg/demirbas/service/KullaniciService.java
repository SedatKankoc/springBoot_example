package com.demirbasUyg.demirbas.service;

import java.util.ArrayList;

import com.demirbasUyg.demirbas.model.Kullanici;

public interface KullaniciService {
	
	Kullanici kullaniciKaydet(Kullanici kullanici);
	Kullanici kullaniciGuncelle(Kullanici kullanici);
	void kullaniciSil(Long id);
	ArrayList<Kullanici> kullaniciListele();
	Kullanici idyeGoreKullaniciGetir(Long id) throws Exception;
	
}
