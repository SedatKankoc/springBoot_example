package com.demirbasUyg.demirbas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemirbasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemirbasApplication.class, args);
	}

}
