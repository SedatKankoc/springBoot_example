package com.demirbasUyg.demirbas.controller;

import java.time.LocalDate;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demirbasUyg.demirbas.model.Kullanici;
import com.demirbasUyg.demirbas.service.KullaniciService;

@RestController
@RequestMapping(value = "/kullanici")
public class KullaniciController {

	Logger log = LoggerFactory.getLogger(KullaniciController.class);

	private KullaniciService kullaniciService;

	public KullaniciController(KullaniciService kullaniciService) {
		super();
		this.kullaniciService = kullaniciService;
	}

	@GetMapping
	public ArrayList<Kullanici> kullanicilariListele() throws Exception {
		log.info("Kullancılar listelendi.");
		ArrayList<Kullanici> kullanicilar = kullaniciService.kullaniciListele();
		if (kullanicilar == null) {
			throw new Exception("Listede Kayıtlı Kullanıcı Bulunamadı!");
		}
		return kullanicilar;
	}

	@PostMapping
	public Kullanici kullaniciKaydet(@RequestBody Kullanici kullanici) throws Exception {
		Kullanici result = new Kullanici();
		log.info("Save record request : " + kullanici.toString());
		try {
			if (kullanici.getAd() == null) {
				throw new Exception("Kullanıcı kaydederken ad kısmı boş bırakılamaz!");
			}
			if (kullanici.getSoyad() == null) {
				throw new Exception("Kullanıcı kaydederken soyad kısmı boş bırakılamaz!");
			}
			kullanici.setDurum(1);
			kullanici.setGirisTarihi(LocalDate.now());
			kullanici.setCıkısTarihi(null);
			result = kullaniciService.kullaniciKaydet(kullanici);
			log.info("Kaydedilen Kullanıcı:" + result.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return kullaniciService.kullaniciKaydet(kullanici);
	}

	@PutMapping
	public Kullanici kullaniciGuncelle(@RequestBody Kullanici inputKullanici) throws Exception {
		Kullanici kayitliKullanici = kullaniciService.idyeGoreKullaniciGetir(inputKullanici.getId());
		log.info("Update record request" + inputKullanici.toString());
		if (inputKullanici.getAd() != null && !inputKullanici.getAd().isEmpty()
				&& (kayitliKullanici.getAd() == null || kayitliKullanici.getAd().isEmpty())
				|| inputKullanici.getAd() != null && !inputKullanici.getAd().isEmpty()
						&& kayitliKullanici.getAd() != null
						&& inputKullanici.getAd().compareTo(kayitliKullanici.getAd()) != 0) {
			kayitliKullanici.setAd(inputKullanici.getAd());
		}
		if (inputKullanici.getSoyad() != null && !inputKullanici.getSoyad().isEmpty()
				&& (kayitliKullanici.getSoyad() == null || kayitliKullanici.getSoyad().isEmpty())
				|| inputKullanici.getSoyad() != null && !inputKullanici.getSoyad().isEmpty()
						&& kayitliKullanici.getSoyad() != null
						&& inputKullanici.getSoyad().compareTo(kayitliKullanici.getSoyad()) != 0) {
			kayitliKullanici.setSoyad(inputKullanici.getSoyad());
		}
		if (inputKullanici.getEmail() != null && !inputKullanici.getEmail().isEmpty()
				&& (kayitliKullanici.getEmail() == null || kayitliKullanici.getEmail().isEmpty())
				|| inputKullanici.getEmail() != null && !inputKullanici.getEmail().isEmpty()
						&& kayitliKullanici.getEmail() != null
						&& inputKullanici.getEmail().compareTo(kayitliKullanici.getEmail()) != 0) {
			kayitliKullanici.setEmail(inputKullanici.getEmail());
		}
		if (inputKullanici.getTelNo() != null && !inputKullanici.getTelNo().isEmpty()
				&& (kayitliKullanici.getTelNo() == null || kayitliKullanici.getTelNo().isEmpty())
				|| inputKullanici.getTelNo() != null && !inputKullanici.getTelNo().isEmpty()
						&& kayitliKullanici.getTelNo() != null
						&& inputKullanici.getTelNo().compareTo(kayitliKullanici.getTelNo()) != 0) {
			kayitliKullanici.setTelNo(inputKullanici.getTelNo());
		}
		log.info("Güncellenen Kullanıcı:" + kayitliKullanici.toString());
		return kullaniciService.kullaniciGuncelle(kayitliKullanici);
	}

	@DeleteMapping("/{id}")
	public void kisiyiTamamenSil(@PathVariable(value = "id") Long id) throws Exception {
		log.info("Silinmesi istenen kullanıcı id:" + id);
		Kullanici kayitliKullanici = kullaniciService.idyeGoreKullaniciGetir(id);
		kullaniciService.kullaniciSil(id);
		log.info("Silinen Kullanıcı bilgileri: " + kayitliKullanici);
	}

}
