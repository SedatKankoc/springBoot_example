package com.demirbasUyg.demirbas.serviceImpl;

import java.util.ArrayList;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Service;

import com.demirbasUyg.demirbas.model.Kullanici;
import com.demirbasUyg.demirbas.repository.KullaniciRepository;
import com.demirbasUyg.demirbas.service.KullaniciService;

@Service
public class KullaniciServiceImpl implements KullaniciService{
	@PersistenceContext
	private EntityManager entityManager;
	public final KullaniciRepository kullaniciRepository;
	
	public KullaniciServiceImpl(EntityManager entityManager, KullaniciRepository kullaniciRepository) {
		super();
		this.entityManager = entityManager;
		this.kullaniciRepository = kullaniciRepository;
	}

	
	@Override
	public Kullanici kullaniciKaydet(Kullanici kullanici) {
		Kullanici kullaniciKayıt = kullaniciRepository.save(kullanici);
		return kullaniciKayıt;
	}

	@Override
	public Kullanici kullaniciGuncelle(Kullanici kullanici) {
		Kullanici kullaniciGuncelle = kullaniciRepository.save(kullanici);
		return kullaniciGuncelle;
	}

	@Override
	public void kullaniciSil(Long id) {
		kullaniciRepository.deleteById(id);
	}

	@Override
	public ArrayList<Kullanici> kullaniciListele() {
		return (ArrayList<Kullanici>) kullaniciRepository.findAll();
	}


	@Override
	public Kullanici idyeGoreKullaniciGetir(Long id) throws Exception {
		Optional<Kullanici> result = kullaniciRepository.findById(id);
		if(result == null) {
			throw new Exception("Girilen id'ye ait kullanıcı bulunamadı!");
		}
		return result.get();
	}
	
	
}
